#include <stdio.h>

int main(){
    //Братков Павел 2.17
    int k,x;
    x = 34565;
    k = x % 1000 / 100;
    printf("%d",k);
    return 0;
}
