#include <stdio.h>

int main(){
    //Братков Павел 2.16 2x^4-3x^3+4x^2-5x+6
    float x = 1.2, y;
    y = 2*x*x*x*x - 3*x*x*x + 4*x*x-5*x+6;
    printf("y = %f\n",y);
    return 0;

}
