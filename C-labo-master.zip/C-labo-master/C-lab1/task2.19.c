#include <stdio.h>

int main(){
    //Братков Павел 2.19
    int k;
    float x;
    x = 1.23;
    k = (x * 10);
    k = k % 10;
    printf("%d\n",k);
    return 0;
}
