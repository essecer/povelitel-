#include <stdio.h>

int main(){
    float y,x;
    y = 2.2;
    x = 3.2;
    printf("%d - True = x < x + y\n", x < x+y);
}
