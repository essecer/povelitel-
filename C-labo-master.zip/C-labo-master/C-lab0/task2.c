#include <stdio.h>
#include <math.h>
int main() {
    float a,b,c,d,x1,x2;
    a = 3;
    b = 8;
    c = 5;
    d = b*b - 4 * a * c ;
    if (d > 0)  {
    	x1 = (b+sqrt(d))/2*a;
    	x2 = (b-sqrt(d))/2*a;
    	printf("Корни уравнения%4.2f,%4.2f",x1,x2);
    	}
    if (d == 0) {
    	x1 = (b+sqrt(d))/2*a;
    	printf("Корень уравнения%4.2f",x1);
    }
	if (d < 0) {
		printf("Корней нет");
	}
	
    	
    
}
